from flask import Flask, jsonify
from pymongo import MongoClient
import config_management

client = MongoClient("mongodb+srv://madans131295:Madan%401359@cluster0.p0rwtzf.mongodb.net/")
db = client['configurationDB']
collection = db['configuration_details']

app = Flask(__name__)

@app.route("/api/configuration-details", methods=["GET"])
def getConfigurationDetails():
    config_details = list(collection.find({}, {'_id':0}))
    return config_details

@app.route("/api/configuration-details", methods=["POST"])
def postConfigurationDetails():
    details = config_management.getConfigFileData()
    print(details)
    if details != None:
        collection.insert_one(details)
        return jsonify({"message":"Added Configuration Data Successfully!!!"})
    else:
        return jsonify({"message":"Error occured while inserting Data to Database."})


if __name__ == "__main__":
    app.run(port=3000, debug=True)