import configparser

def getConfigFileData():
     try:
        config_dict = {}
        parser = configparser.ConfigParser()
        parser.read_file(open("./config.ini", "r"))
        for section in parser.sections():
            print(section)
            config_dict[section] = {}
            for k,v in parser.items(section):
                config_dict[section][k] = v
        return config_dict
     except:
         print("File Does not exist")






















# def getConfigDetailsFromFile():
#     try:
#         config_dict = {}
#         file = open("config.txt", "r")
#         content = file.read()
#         listOfContent = content.split("\n")
#         new_config = True
#         for lst in listOfContent:
#             if lst == "":
#                 new_config = True
#                 continue
#             else:
#                 if new_config == True:
#                     config_dict[lst] = {}
#                     curConfig = lst
#                     new_config = False
#                 else:
#                     value = lst.split("=")
#                     config_dict[curConfig][value[0]] = value[1]
#         print("Test")
#         final_config = json.dumps(config_dict)
#         print(final_config)
#         file.close()
#         return final_config
#     except:
#         print("File Not Found Exception...")